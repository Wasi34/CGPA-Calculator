﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSE3200_Offline_190104034
{

    public partial class Form1 : Form
    {
        public static double GPA;
        public static string S_Name;

        public Form1()
        {
            InitializeComponent();
        }

        private void Name_TextChanged(object sender, EventArgs e)
        {

        }

        private bool NameVerify(string n)
        {
            int count = 0;
            for (int i = 0; i < n.Length; i++)
            {
                if (n[i] == '0' || n[i] == '1' || n[i] == '2' || n[i] == '3' || n[i] == '4' || n[i] == '5' || n[i] == '6' || n[i] == '7' || n[i] == '8' || n[i] == '9')
                    count++;
            }

            if (count == 0) return true;
            else return false;

        }

        private double CGPA(int marks)
        {
            if (marks >= 80 && marks <= 100)

                return 4.00;

            else if (marks >= 75 && marks < 80)

                return 3.75;

            else if (marks >= 70 && marks < 75)

                return 3.50;

            else if (marks >= 65 && marks < 70)

                return 3.25;

            else if (marks >= 60 && marks < 65)

                return 3.00;

            else if (marks >= 55 && marks < 60)

                return 2.75;

            else if (marks >= 50 && marks < 55)

                return 2.50;

            else if (marks >= 45 && marks < 50)

                return 2.25;

            else if (marks >= 40 && marks < 45)

                return 2.00;

            else if (marks >= 0 && marks < 40)

                return 0.00;

            else
                return -1;

        }


        private void button1_Click(object sender, EventArgs e)
        {
            S_Name = Student_Name.Text;
            string id;
            id = ID.Text;

            if (NameVerify(S_Name))
            {
                double Grade = 0.00;
                try
                {
                    if (S_Name == "")
                    {
                        MessageBox.Show("Please Enter your Name.");
                    }
                    else if (id == "")
                    {
                        MessageBox.Show("Please Enter your ID.");
                    }
                    else if (Regex.IsMatch(ID.Text, @"^\d+$"))
                    {
                        var id_3 = id.Substring(id.Length - 3);
                        int x = Int32.Parse(id_3);

                        if (id.Length != 11 || x >100 ||x==0 )
                        {
                            MessageBox.Show("ID format is not correct.");

                        }

                        else if (id[0] != '2' || id[1] != '0' || id[2] != '2' || id[3] != '1' || id[4] != '0' || id[5] != '2' || id[6] != '0' || id[7] != '4')
                        {
                            MessageBox.Show("You are not from CSE 1.1!");
                        }

                        else
                        {
                            int C1 = Convert.ToInt32(CHEM1115.Value);
                            int C2 = Convert.ToInt32(CSE1101.Value);
                            int C3 = Convert.ToInt32(CSE1102.Value);
                            int C4 = Convert.ToInt32(CSE1108.Value);
                            int C5 = Convert.ToInt32(HUM1107.Value);
                            int C6 = Convert.ToInt32(HUM1108.Value);
                            int C7 = Convert.ToInt32(MATH1115.Value);
                            int C8 = Convert.ToInt32((PHY1115.Value));
                            int C9 = Convert.ToInt32((PHY1116.Value));

                            if ((C3 < 40 && C3 >= 0) || (C4 < 40 && C4 >= 0) || (C6 < 40 && C6 >= 0) || (C9 < 40 && C9 >= 0))

                            {
                                MessageBox.Show("Sorry, you failed in lab.");

                            }
                            else
                            {

                                if (CGPA(C1) == -1 || CGPA(C2) == -1 || CGPA(C3) == -1 || CGPA(C4) == -1 || CGPA(C5) == -1 || CGPA(C6) == -1 || CGPA(C7) == -1 || CGPA(C8) == -1 || CGPA(C9) == -1)
                                {
                                    MessageBox.Show("Invalid input of marks!");
                                }

                                else
                                {
                                    double credit_3 = Convert.ToDouble(credit3.Text.ToString());
                                    double credit_1point5 = Convert.ToDouble(credit1point5.Text.ToString());
                                    double credit_point75 = Convert.ToDouble(creditpoint75.Text.ToString());

                                    Grade += CGPA(C1) * credit_3;
                                    Grade += CGPA(C2) * credit_3;
                                    Grade += CGPA(C3) * credit_1point5;
                                    Grade += CGPA(C4) * credit_1point5;
                                    Grade += CGPA(C5) * credit_3;
                                    Grade += CGPA(C6) * credit_1point5;
                                    Grade += CGPA(C7) * credit_3;
                                    Grade += CGPA(C8) * credit_3;
                                    Grade += CGPA(C9) * credit_point75;

                                    GPA = Grade / 20.25;

                                    Form2 F2 = new Form2(this, GPA);
                                    F2.Show();
                                    Visible = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Your ID contains letters!");
                    }

                }
                catch (IndexOutOfRangeException ex)
                {
                    MessageBox.Show("Invalid ID or Name.");
                }
            }

            else
                MessageBox.Show("Your name should not contain numbers.");

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
