﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSE3200_Offline_190104034
{
    public partial class Form2 : Form
    {
        Form1 f1;
        double GPA;
        public Form2(Form1 f1, double gpa)
        {
            InitializeComponent();
            this.f1 = f1;
            this.GPA = gpa;
        }

        private void Result(object sender, EventArgs e)
        {
            string S = f1.Student_Name.Text;
            Welcome.Text = $"Welcome {S} to the GPA Generator!";
           
            GPA_Result.Text = $"Your acquired GPA is {GPA}";
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            Visible = false;
        }
    }
}
